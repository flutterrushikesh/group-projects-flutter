import 'package:flutter/material.dart';
class ItemData {
  final Color color;
  final String lottieFilePath;
  final String text1;
 
  ItemData(this.color, this.lottieFilePath, this.text1,);
}